# TheDonax Android project

Este proyecto empaqueta `TheDonax.html` dentro de una app Android sencilla con WebView. No se ha compilado aquí una APK; usa GitHub Actions para compilarla en la nube desde tu teléfono.

## Cómo generar la APK solo con el teléfono

1. Descomprime este ZIP.
2. Crea un repositorio en https://github.com/new (puedes usar el navegador del teléfono).
3. Sube el contenido de esta carpeta al repositorio, manteniendo las carpetas y archivos.
4. Abre la pestaña **Actions** del repositorio y permite los workflows si GitHub lo solicita.
5. Ejecuta **Build TheDonax APK** con **Run workflow** (o espera a que termine la compilación al subir los archivos).
6. Abre la ejecución terminada y descarga el artefacto **TheDonax-APK**. Dentro estará `app-debug.apk`.
7. Abre la APK en el teléfono y autoriza la instalación desde esa fuente si Android lo solicita.

## Importante
- Esta es una APK de depuración para pruebas e instalación manual, no una versión firmada para publicar en Google Play.
- Los enlaces externos web se abren en el navegador. La app necesita internet para los enlaces externos.
- El HTML conserva su JavaScript y almacenamiento local del WebView.
